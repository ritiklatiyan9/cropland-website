import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { UserModel } from '../models/user.model.js'

const signToken = (user) =>
  jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' },
  )

export const register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'name, email and password are required' })
    }

    const existing = await UserModel.findByEmailWithPassword(email)
    if (existing) {
      return res.status(409).json({ message: 'Email already in use' })
    }

    const hash = await bcrypt.hash(password, 10)
    const user = await UserModel.create({ name, email, password: hash })
    const token = signToken(user)
    res.status(201).json({ user, token })
  } catch (err) {
    next(err)
  }
}

export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body
    if (!email || !password) {
      return res.status(400).json({ message: 'email and password are required' })
    }

    const user = await UserModel.findByEmailWithPassword(email)
    if (!user) return res.status(401).json({ message: 'Invalid credentials' })

    const ok = await bcrypt.compare(password, user.password)
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' })

    const { password: _pw, ...safe } = user
    const token = signToken(safe)
    res.json({ user: safe, token })
  } catch (err) {
    next(err)
  }
}

export const list = async (_req, res, next) => {
  try {
    const users = await UserModel.findAll()
    res.json(users)
  } catch (err) {
    next(err)
  }
}

export const getOne = async (req, res, next) => {
  try {
    const user = await UserModel.findById(req.params.id)
    if (!user) return res.status(404).json({ message: 'User not found' })
    res.json(user)
  } catch (err) {
    next(err)
  }
}

export const update = async (req, res, next) => {
  try {
    const { name, email } = req.body
    const user = await UserModel.update(req.params.id, { name, email })
    if (!user) return res.status(404).json({ message: 'User not found' })
    res.json(user)
  } catch (err) {
    next(err)
  }
}

export const remove = async (req, res, next) => {
  try {
    const ok = await UserModel.remove(req.params.id)
    if (!ok) return res.status(404).json({ message: 'User not found' })
    res.status(204).send()
  } catch (err) {
    next(err)
  }
}

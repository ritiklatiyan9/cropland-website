import { Router } from 'express'
import {
  register,
  login,
  list,
  getOne,
  update,
  remove,
} from '../controllers/user.controller.js'
import { requireAuth } from '../middleware/auth.js'

const router = Router()

router.post('/register', register)
router.post('/login', login)

router.get('/', requireAuth, list)
router.get('/:id', requireAuth, getOne)
router.put('/:id', requireAuth, update)
router.delete('/:id', requireAuth, remove)

export default router

import { query } from '../config/db.js'

const PUBLIC_COLS = 'id, name, email, role, created_at, updated_at'

export const UserModel = {
  async create({ name, email, password, role = 'user' }) {
    const sql = `
      INSERT INTO users (name, email, password, role)
      VALUES ($1, $2, $3, $4)
      RETURNING ${PUBLIC_COLS}
    `
    const { rows } = await query(sql, [name, email, password, role])
    return rows[0]
  },

  async findAll() {
    const { rows } = await query(`SELECT ${PUBLIC_COLS} FROM users ORDER BY id DESC`)
    return rows
  },

  async findById(id) {
    const { rows } = await query(
      `SELECT ${PUBLIC_COLS} FROM users WHERE id = $1`,
      [id],
    )
    return rows[0]
  },

  // Includes password — used only for login flow
  async findByEmailWithPassword(email) {
    const { rows } = await query(
      `SELECT id, name, email, password, role FROM users WHERE email = $1`,
      [email],
    )
    return rows[0]
  },

  async update(id, { name, email }) {
    const sql = `
      UPDATE users
      SET name = COALESCE($1, name),
          email = COALESCE($2, email)
      WHERE id = $3
      RETURNING ${PUBLIC_COLS}
    `
    const { rows } = await query(sql, [name, email, id])
    return rows[0]
  },

  async remove(id) {
    const { rowCount } = await query(`DELETE FROM users WHERE id = $1`, [id])
    return rowCount > 0
  },
}

import pkg from 'pg'
import dotenv from 'dotenv'

dotenv.config()

const { Pool } = pkg

const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
})

pool.on('connect', () => {
  console.log('PostgreSQL connected')
})

pool.on('error', (err) => {
  console.error('Unexpected Postgres pool error', err)
  process.exit(-1)
})

export const query = (text, params) => pool.query(text, params)
export default pool

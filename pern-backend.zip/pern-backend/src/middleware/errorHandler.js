export const notFound = (req, res, _next) => {
  res.status(404).json({ message: `Route ${req.originalUrl} not found` })
}

export const errorHandler = (err, _req, res, _next) => {
  console.error(err)
  const status = err.status || 500
  res.status(status).json({
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  })
}

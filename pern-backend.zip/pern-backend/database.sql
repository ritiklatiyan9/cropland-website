-- Cropland database schema
-- Run: psql -U postgres -f database.sql

CREATE DATABASE cropland;
\c cropland;

CREATE TABLE IF NOT EXISTS users (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) UNIQUE NOT NULL,
    password    VARCHAR(255) NOT NULL,
    role        VARCHAR(20)  NOT NULL DEFAULT 'user',
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Auto-update updated_at on row change
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_users_updated_at ON users;
CREATE TRIGGER trg_users_updated_at
BEFORE UPDATE ON users
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

-- Optional seed (password is bcrypt hash of "admin123")
-- INSERT INTO users (name, email, password, role)
-- VALUES ('Admin', 'admin@cropland.com',
--         '$2a$10$kIqR2YQ8Y3kI9wO7Yp1H1uYwH8w7bD5j0kQ1aQ1aQ1aQ1aQ1aQ1aQ', 'admin');
